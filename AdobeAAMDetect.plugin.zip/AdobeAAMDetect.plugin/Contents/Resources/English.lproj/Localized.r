#include <CoreServices/CoreServices.r>

resource 'STR#' (126) 
{ {
    "Copyright 2015 Adobe Systems",
    "AdobeAAMDetect"
} };

resource 'STR#' (127) 
{ {
    "",
} };

resource 'STR#' (128) 
{ {
    "application/x-adobeaamdetect",
    "",
} };
